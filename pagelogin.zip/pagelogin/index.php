<?php
include "conn.php";		
$name = $_POST['name'];
$password = $_POST['pwd'];
mysqli_query($connection, $query)
$query = "INSERT INTO sample VALUES(?, ?);";
$initialize = mysqli_stmt_init($connection);
if(mysqli_stmt_prepare($initialize, $query))
{
    mysqli_stmt_bind_param($initialize, "ss", $name, $password);
    mysqli_stmt_execute($initialize);
}
?>
