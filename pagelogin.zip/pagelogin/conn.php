<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "project";
$connection = mysqli_connect($serverName, $userName, $password, $databaseName);
?>
